CryptoAlarm Nobitex - Advanced local Android app (ZIP)
----------------------------------------------------
This is a scaffold for an on-device analysis app that focuses on Nobitex markets.
Open in Android Studio, build APK, install on your device.

Quick steps:
1) Open project in Android Studio
2) Build -> Build APK(s)
3) Install app-debug.apk from app/build/outputs/apk/debug/

GitHub Actions included (.github/workflows/build-android.yml)
